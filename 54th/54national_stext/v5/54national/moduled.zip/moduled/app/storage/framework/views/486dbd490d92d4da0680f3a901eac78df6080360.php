<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Document</title>
        <link rel="stylesheet" href="index.css">
    </head>
    <body>

    </body>
</html><?php /**PATH C:\xampp\htdocs\website\52th\senior\52national\TaskD\app\resources\views/welcome.blade.php ENDPATH**/ ?>